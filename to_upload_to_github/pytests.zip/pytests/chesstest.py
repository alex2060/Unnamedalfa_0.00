




import requests
import webbrowser
import random
username= "example"
password= "1qazwsxedCr"

f = open("chess.html", "r")
example=f.read()
f.close()
path = "http://alexhaussmann.com/adhaussmann/a_final/"
url = path+'add_template.php'

example=example.replace("\\", "(!D???!???D!)")

#(!D???!???D!)

#2fe1fb50c75474cf58c16bfd4db665a4dd03b271c272c00f969d95af000cdfd7

print(url)
random_string =""
for x in range(30):
	random_integer = random.randint(66, 89)
	# Keep appending random characters using chr(x)
	random_string += (chr(random_integer))
value=random_string
myobj = {"uname":username,"hashword":password,"template_name":"mygame"+value, 'template': example}


x = requests.post(url, data = myobj)
print(x)

webbrowser.get("firefox").open("http://alexhaussmann.com/adhaussmann/a_final/make_newpage.php?usertemplate_name=example_mygame"+value+"&var1=W")






