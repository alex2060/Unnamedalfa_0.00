import requests
import random
import webbrowser

email = "alex.haussmann@gmail.com"


random_string = ''

for x in range(30):
	random_integer = random.randint(66, 89)
	# Keep appending random characters using chr(x)
	random_string += (chr(random_integer))

myusername = random_string

userpassword    = "pass1"
ledgurename     = "led"
leduerpassword  = "ledpass1"

path = "http://alexhaussmann.com/adhaussmann/a_final"

adduser =    path+"/add_user_dev.php?uname="+myusername+"&hashword="+userpassword+"&email="+email
addleddgure =path+"/add_ledger_dev.php?uname="+myusername+"&hashword="+userpassword+"&Ledgure="+ledgurename+"&password="+leduerpassword+"&email="+email
addkey =     path+"/add_key_dev.php?uname="+myusername+"_"+ledgurename+"&password="+leduerpassword+"&email="+email
addprem	=    path+"/add_post_dev.php?uname="+myusername+"&hashword="+userpassword+"&tital=works&text=works&body=works&photo=works&iframe=https://www.youtube.com/embed/xcJtL7QggTI&catagoy=prem&catagoy_2=P+"+myusername+"_"+ledgurename


for x in range(5):
	print("")
print("add user")
x = requests.get(adduser)
print(str(x.content).strip("\n"))

for x in range(5):
	print("")
print("add leddgure")

x = requests.get(addleddgure)
print(str(x.content).strip("\n"))
for x in range(5):
	print("")
print("add key")
x = requests.get(addkey)
print(str(x.content).strip("\n"))

for x in range(5):
	print("")
print("add premium")
x = requests.get(addprem)
print(str(x.content).strip("\n"))
print(addprem)


f = open("example.html", "r")
example=f.read()
f.close()
randomval=""

url = path+"/add_template_dev.php"
example=example.replace("\\", "(!D???!???D!)")
myobj = {"uname":myusername,"hashword": userpassword,"template_name":"premium_example", 'template': example}
x = requests.post(url, data = myobj)
for k in range(5):
	print("")
print("add template")
print(x.content)
webbrowser.get("firefox").open(path+"/make_newpage.php?usertemplate_name="+myusername+"_premium_example&var1=prem?"+myusername)





















